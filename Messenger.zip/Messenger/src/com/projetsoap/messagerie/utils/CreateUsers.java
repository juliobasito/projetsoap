package com.projetsoap.messagerie.utils;

import org.hibernate.Session;

import com.projetsoap.srcfiles.User;
import com.projetsoap.utils.DatabaseOperations;

public class CreateUsers {
	
	public static void main(String[] args){
//		User admin = new User("Thibault", "Gautier", "titi@truck.fr","0619092518" , "titi", 33, 1, "yes");
//		Session s = DatabaseOperations.Connection(User.class);
//		DatabaseOperations.SaveDatas(s, admin);
//		DatabaseOperations.CloseConnection(s);
//		
//		User truck = new User("Louis", "Charbonier", "loulou@truck.fr","0101010101" , "loulou", 33, 0, "yes");
//		Session s = DatabaseOperations.Connection(User.class);
//		DatabaseOperations.SaveDatas(s, truck);
//		DatabaseOperations.CloseConnection(s);
	}
}
